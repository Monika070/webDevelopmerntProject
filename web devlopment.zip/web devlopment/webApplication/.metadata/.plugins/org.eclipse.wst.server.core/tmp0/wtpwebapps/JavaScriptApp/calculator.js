/*calculation function*/
function performCalculation(){
	let x=parseInt(document.getElementById("operand1").value);
	let y=parseInt(document.getElementById("operand2").value);
	let z=document.getElementById("operator").value;
	alert(x+y+z);
	let r=0;
	switch(z){
	case "+":r=x+y;break;
	case "-":r=x+y;break;
	case "x":r=x+y;break;
	case "/":r=x+y;break;
	}
	document.getElementById("Result").value=r;
	}
/*focusing to 1st textfield at loading of window at loading of window*/
function setFocus(){
	document.getElementById("operand1").focus();
}
function clearAll(){
	document.getElementById("calculatorForm").reset();
	setFocus();
}
function checkNumber(obj){
	//let p=0;
	let x=obj.value;
	while(isNaN(x)){
	
		x=prompt("Enter a whole number");
		obj.value=p;
	}
	obj.value=x;
}